
--------------------------------------------------------------------------------------------------------------------------------------------------
          Iterated scheme for selecting regularization parameter to achieve target NNZ (number of nonzeros of the solution)

		    classification problem
--------------------------------------------------------------------------------------------------------------------------------------------------

(1) How to Use
------------------------------

Initialize the variable "paraFPPA.TargetNNZ" in the program "Main_Classification_SquareLoss_L1_FPPA.m"

Run the program "Main_Classification_SquareLoss_L1_FPPA.m"

Initialize the varible "TargetNNZ" in the program "AnalysisResults.m"

Run the program "Main_Classification_SquareLoss_L1_FPPA.m"


(4) Contact Information
------------------------------

For any comments and suggestions, please feel free to email:

Qianru Liu, School of Mathematics, Jilin Univ., (liuqr19@jlu.edu.cn)
Mingsong Yan, Department of Mathematics and Statistics, Old Dominion Univ., (myan007@odu.edu)
